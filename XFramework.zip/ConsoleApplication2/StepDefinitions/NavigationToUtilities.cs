﻿using System;
using OpenQA.Selenium;
using NUnit.Framework;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using System.Collections.Generic;

namespace BDDFrameworkXavid.Utilities
{
    class NavigationToUtilities
    {
        private static ICollection<string> str;

        internal static void LauchUrl(IWebDriver driver, string strAppName)
        {
            try
            {
                string strUrl = WebUtilities.fetchParamValFromConfig(strAppName);
                
                //Navigating to Home page
                driver.Navigate().GoToUrl(strUrl);

                //Entering UserName and Password
                driver.FindElement(By.ClassName("login")).Click();
                driver.FindElement(By.Id("email")).SendKeys("Abhilash.giridharan@ust-global.com");

                //Decrypting password
                String password = WebUtilities.decryptString("TG9zdEAxMjM=");
                driver.FindElement(By.Id("passwd")).SendKeys(password);

                driver.FindElement(By.Id("SubmitLogin")).Click();
                System.Threading.Thread.Sleep(5000);

            }
            catch (Exception e)
            {
                Assert.Fail("Failed to lauch the URL, please find the log below for more details" + e);
            }

        }

        internal static void NavToScreen(IWebDriver driver, string screenName)
        {
            if(screenName.Equals("my personal information"))
            {
                driver.FindElement(By.XPath("//a[@title='Information']")).Click();
                System.Threading.Thread.Sleep(5000);
            }
        }

        internal static void NavToValidateVal(IWebDriver driver, Table tableOfVal)
        {
            dynamic data = tableOfVal.CreateDynamicInstance();
            int headerCount = tableOfVal.Header.Count;
            for (int i = 0; i < headerCount; i++)
            {
                string[] returnArray = new string[tableOfVal.Header.Count];
                tableOfVal.Header.CopyTo(returnArray, 0);

                if (returnArray[i].Equals("FirstName"))
                {
                    string objVal = driver.FindElement(By.Id("firstname")).GetAttribute("value");
                    if (!objVal.Equals(data.FirstName))
                    {
                        Assert.Fail("Validation failed, expected: "+ data.FirstName+ " actual: "+ objVal);
                    }
                }
                if (returnArray[i].Equals("LastName"))
                {
                    string objVal = driver.FindElement(By.Id("lastname")).GetAttribute("value");
                    if (!objVal.Equals(data.LastName))
                    {
                        Assert.Fail("Validation failed, expected: " + data.LastName + " actual: " + objVal);
                    }
                }
                if (returnArray[i].Equals("EmailAddress"))
                {
                    string objVal = driver.FindElement(By.Id("email")).GetAttribute("value");
                    if (!objVal.Equals(data.EmailAddress))
                    {
                        Assert.Fail("Validation failed, expected: " + data.EmailAddress + " actual: " + objVal);
                    }
                }
            }
            Console.WriteLine("Validation is successfuly done");
        }
    }
}
