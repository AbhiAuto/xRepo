﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using System.Threading.Tasks;
using BDDFrameworkXavid.Utilities;
using System.Diagnostics;

namespace BDDFrameworkXavid
{
    [Binding]
    class StepDefinition
    {
        public IWebDriver driver = BrowserManager.GetCurrentBrowserDriver();


        [Given(@"I have logged into ""(.*)"" portal")]
        public void GivenIHaveLoggedIntoPortal(string strAppName)
        {
            NavigationToUtilities.LauchUrl(driver, strAppName);
        }

        [When(@"I navigate to ""(.*)"" screen")]
        public void WhenINavigateToScreen(string screenName)
        {
            NavigationToUtilities.NavToScreen(driver, screenName);
        }

        [Then(@"I should successfully see the details displayed:")]
        public void ThenIShouldSuccessfullySeeTheDetailsDisplayed(Table tableOfVal)
        {
            NavigationToUtilities.NavToValidateVal(driver, tableOfVal);
        }

    }

}