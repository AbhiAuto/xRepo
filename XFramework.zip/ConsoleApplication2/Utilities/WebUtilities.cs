﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDDFrameworkXavid.Utilities
{

    static class WebUtilities
    {
        public static string ConfigParamValReturn(this string strParamFind)
        {
            return ConfigurationManager.AppSettings["Browser"];
        }

        internal static string fetchParamValFromConfig(string strParam)
        {
            return ConfigurationManager.AppSettings[strParam];
        }

        public static string getDirPath()
        {
            string strDebugDir = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            string strDirPath = strDebugDir.Replace("\\bin\\Debug\\", "");
            return strDirPath;
        }

        public static string decryptString(string strPassword)
        {
            byte[] data = Convert.FromBase64String(strPassword);
            string decodedString = Encoding.UTF8.GetString(data);
            return decodedString;
        }
    }
    public class Constants
    {
        public const int ImplicitWaitTime = 20;
        public const int PageLoadWaitTime = 90;
        public const int DefaultWaitInSeconds = 5;
        public const int DefaultPollingWaitInMilliSeconds = 200;

    }


}
